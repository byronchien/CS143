We split the creation of tables, loading data, and violate.sql evenly. Byron did query.php and Nat did queries.sql.
