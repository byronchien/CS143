We implemented all the project criteria. You can add different people, movies,
and relationships between people and movies. Our website also allows you to
search for people and movies and links to more information about them.

For this project, Byron was responsible for the search and browsing functionality
and Nathaniel was responsible for the input functionality.