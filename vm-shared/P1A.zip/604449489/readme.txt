We listed cases to check for and divided them between us. For those cases, we worked
indepenedently to implement solutions and we pair programmed to check for any that 
we missed before we turned the project in.
