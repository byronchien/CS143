We added constructors for the different kinds of nodes.
Byron Chien - byronc@ucla.edu
Nathaniel Chu - nathanielchu4.gmail.com
For the splitting of work, one of us handled the leaf nodes
and the other handled the non-leaf nodes.
